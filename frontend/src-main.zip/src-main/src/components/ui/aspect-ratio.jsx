import React from "react";
import { Root as AspectRatioRoot } from "@radix-ui/react-aspect-ratio";

const AspectRatio = AspectRatioRoot;

export { AspectRatio };

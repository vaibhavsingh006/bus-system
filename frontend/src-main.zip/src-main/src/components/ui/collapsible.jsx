import { Root, CollapsibleTrigger, CollapsibleContent } from "@radix-ui/react-collapsible";

const Collapsible = Root;

export { Collapsible, CollapsibleTrigger, CollapsibleContent };

import React from "react"

import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import { ArrowRight } from "lucide-react";

// Mock bus data
const mockBusDetails = {
  id: 1,
  name: "Express Deluxe",
  operator: "National Express",
  departureTime: "08:00 AM",
  arrivalTime: "11:30 AM",
  from: "New York",
  to: "Boston",
  date: "2023-06-15",
  price: 45,
  totalSeats: 40,
  bookedSeats: [3, 4, 7, 12, 15, 22, 25, 26, 33, 34, 38],
};

// Generate seat layout
const generateSeats = (totalSeats, bookedSeats) => {
  const seats = [];
  const rows = Math.ceil(totalSeats / 4);

  for (let row = 1; row <= rows; row++) {
    const rowSeats = [];
    for (let col = 1; col <= 4; col++) {
      const seatNumber = (row - 1) * 4 + col;
      if (seatNumber <= totalSeats) {
        rowSeats.push({
          id: seatNumber,
          row,
          col,
          status: bookedSeats.includes(seatNumber) ? "booked" : "available",
        });
      }
    }
    seats.push(rowSeats);
  }

  return seats;
};

const SeatSelectionPage = () => {
  const { busId } = useParams();
  const navigate = useNavigate();
  const [busDetails, setBusDetails] = useState(mockBusDetails);
  const [seats, setSeats] = useState([]);
  const [selectedSeats, setSelectedSeats] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setTimeout(() => {
      setSeats(generateSeats(busDetails.totalSeats, busDetails.bookedSeats));
      setLoading(false);
    }, 1000);
  }, [busDetails]);

  const handleSeatClick = (seatId, status) => {
    if (status === "booked") return;

    setSelectedSeats((prev) =>
      prev.includes(seatId) ? prev.filter((id) => id !== seatId) : [...prev, seatId]
    );
  };

  const getSeatStatus = (seatId) => {
    if (busDetails.bookedSeats.includes(seatId)) return "booked";
    if (selectedSeats.includes(seatId)) return "selected";
    return "available";
  };

  const getTotalPrice = () => {
    return selectedSeats.length * busDetails.price;
  };

  const handleProceedToPayment = () => {
    if (selectedSeats.length === 0) {
      alert("Please select at least one seat to continue.");
      return;
    }

    navigate("/booking-summary", {
      state: {
        busDetails,
        selectedSeats,
        totalPrice: getTotalPrice(),
      },
    });
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <div className="bg-blue-600 py-6">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-white">
            <h1 className="text-2xl font-bold">Select Your Seats</h1>
            <p className="mt-1">{busDetails.name} - {busDetails.operator}</p>
          </div>
        </div>
      </div>

      <div className="flex-grow bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 py-8">
          {loading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
            </div>
          ) : (
            <div className="flex flex-col lg:flex-row gap-8">
              <div className="w-full lg:w-2/3">
                <div className="bg-white rounded-lg shadow-sm p-6">
                  <div className="flex justify-between mb-4">
                    <div>
                      <h2 className="text-xl font-bold">{busDetails.from} to {busDetails.to}</h2>
                      <p className="text-gray-600">{busDetails.date}</p>
                    </div>
                    <div>
                      <div className="flex items-center">
                        <span className="font-semibold">{busDetails.departureTime}</span>
                        <ArrowRight className="mx-2 text-gray-400" />
                        <span className="font-semibold">{busDetails.arrivalTime}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex justify-center">
                    <div className="w-full max-w-md bg-gray-100 p-3 rounded-lg">
                      <div className="text-center font-semibold text-gray-700 mb-2">FRONT</div>
                      <div className="w-full h-1 bg-gray-300 mb-6"></div>

                      <div className="space-y-3">
                        {seats.map((row, rowIndex) => (
                          <div key={rowIndex} className="flex justify-center gap-8">
                            {row.map((seat) => (
                              <button
                                key={seat.id}
                                className={`w-10 h-10 rounded-md flex items-center justify-center text-sm font-medium ${getSeatStatus(seat.id) === "available"
                                  ? "bg-gray-200 hover:bg-gray-300"
                                  : getSeatStatus(seat.id) === "selected"
                                    ? "bg-green-500 text-white"
                                    : "bg-red-500 text-white cursor-not-allowed"
                                  }`}
                                onClick={() => handleSeatClick(seat.id, getSeatStatus(seat.id))}
                                disabled={getSeatStatus(seat.id) === "booked"}
                              >
                                {seat.id}
                              </button>
                            ))}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="w-full lg:w-1/3">
                <div className="bg-white rounded-lg shadow-sm p-6">
                  <h3 className="text-xl font-bold mb-4">Booking Summary</h3>

                  <div className="space-y-4">
                    <div className="flex justify-between"><span>Bus</span><span>{busDetails.name}</span></div>
                    <div className="flex justify-between"><span>Route</span><span>{busDetails.from} to {busDetails.to}</span></div>
                    <div className="flex justify-between"><span>Date</span><span>{busDetails.date}</span></div>
                    <div className="flex justify-between"><span>Time</span><span>{busDetails.departureTime} - {busDetails.arrivalTime}</span></div>
                    <div className="flex justify-between"><span>Selected Seats</span><span>{selectedSeats.join(", ") || "None"}</span></div>
                    <div className="border-t pt-4 flex justify-between">
                      <span>Total Price</span>
                      <span className="font-semibold">${getTotalPrice()}</span>
                    </div>
                  </div>

                  <button onClick={handleProceedToPayment} className="mt-6 w-full bg-blue-600 text-white py-2 rounded-md">
                    Proceed to Payment
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default SeatSelectionPage;
